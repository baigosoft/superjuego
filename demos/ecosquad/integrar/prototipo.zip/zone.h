#ifndef ZONE_H_
#define ZONE_H_

#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include "super.h"


extern int exitzone;





/*funciones zona*/
void init_var_zone();
void load_images_zone();
void clean_images_zone();
void screenzone();




#endif
