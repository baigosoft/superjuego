#ifndef TITLE_H_
#define TITLE_H_

#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include "super.h"

extern int exittitle;

void init_var_title();
void load_images_title();
void clean_images_title();
void screentitle();




























#endif
