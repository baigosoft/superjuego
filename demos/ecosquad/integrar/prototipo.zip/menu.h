#ifndef MENU_H_
#define MENU_H_


#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include "super.h"


extern int exitmenu;

void init_var_menu();
void load_images_menu();
void clean_images_menu();
void screenmenu();
























#endif
